# Desafio 1: Slider

## Desafio do módulo "JavaScript Intermediário" do curso DevQuest 🛡

[<img src="src/img/desktop.gif" alt="Exercício de slides usando JavaScript">](https://kellysondias.github.io/desafio-1-js-intermediario/)

Este exercício é um slider de imagens usando JavaScript e foi a minha primeira aplicação funcional da linguagem.

## Tecnologias utilizadas
- HTML
- CSS
- JavaScript
