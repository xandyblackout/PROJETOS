# Pointer Clock in Javascript
 
 <p align="center">
 <img width="100%" height="600" src="images/pointer-clock-js.gif">
 </p>
 
 # <h1>Technologies Used</h1>
 - HTML 
 - CSS
 - JAVASCRIPT
